menu = (
    "Menu Makanan : "
    "Nasi Goreng : " 
    "Pisang Keju: " 
    "Kue Bakar: " 
    "Ayam Goreng : " 
)


uang = float(int(input("Masukkan jumlah uang Anda: Rp ")))

if uang < 6.000:
    print("Maaf, uang Anda tidak mencukupi untuk memesan makanan.")
elif uang >= 6.000 and uang < 14.000:
    pesanan = input("Anda dapat memesan hanya pesan Pisang Keju. Apakah Anda ingin memesannya? (ya/tidak): ")
    if pesanan == ("ya"):
        print("Pesanan Anda: Pisang Keju. Terima kasih!")
    else:
        print("Terima kasih!")

elif uang >= 14.000 and uang < 20.000:
    pesanan = input("""Anda dapat memesan 
nasi goreng  
pisang keju 
Kue Bakar dan 
Ayam goreng. 
Apa yang ingin Anda pesan? 
(nasi goreng/pisang keju/Kue Bakar/Ayam Goreng): 
""")
    
    if pesanan == ("nasi goreng") :
          print("Pesanan Anda: Nasi Goreng. Terima kasih!")
    elif pesanan == ("pisang keju") :
        print("Pesanan Anda: Pisang Keju. Terima kasih!")
    elif pesanan == ("Kue Bakar") :
        print("Pesanan Anda: Kue Bakar. Terima kasih!")
    elif pesanan == ("Ayam Goreng") :
        print("Pesanan Anda: Ayam Goreng. Terima kasih!")
    else:
        print("Maaf, pilihan tidak valid. Terima kasih!")

else:
    pesanan_nasi_goreng = input("Anda dapat memesan nasi goreng. Apakah Anda ingin memesannya? (ya/tidak): ")
    pesanan_pisang_keju = input("Anda juga dapat memesan pisang keju. Apakah Anda ingin memesannya? (ya/tidak): ")
    
    if pesanan_nasi_goreng == ("ya") and pesanan_pisang_keju == ("ya"):
        print("Pesanan Anda: Nasi Goreng dan Pisang Keju. Terima kasih!")
    elif pesanan_nasi_goreng == ("ya"):
        print("Pesanan Anda: Nasi Goreng. Terima kasih!")
    elif pesanan_pisang_keju == ("ya"):
        print("Pesanan Anda: Pisang Keju. Terima kasih!")
    else:
        print("Terima kasih!")

