nama = "vicky"
pw = "123"
user = False
login = 0
y = "iya"
while True :
    username = input("Masukkan Username Anda: ")
    password = input("Masukkan password Anda: ")
    if username == nama and password == pw :
        print("selamat anda berhasil Login")
        user = True
        break
    else:
        login +=1       
    if login == 3:
        print("Anda telah gagal login 3x. Program akan dihentikan.")
        break
while username == nama and password == pw:
    menu = (
        "Menu Makanan : "
        "Nasi Goreng : " 
        "Pisang Keju: " 
        "Kue Bakar: " 
        "Ayam Goreng : " 
        )
    uang = float(input("Masukkan jumlah uang Anda: Rp "))
    if uang < 6.000:
        print("Maaf, uang Anda tidak mencukupi untuk memesan makanan.")
        break
    elif uang >= 6.000 and uang < 14.000:
        pesanan = input("Anda dapat memesan hanya pesan Pisang Keju. Apakah Anda ingin memesannya? (ya/tidak): ")
        if pesanan == ("ya"):
            print("Pesanan Anda: Pisang Keju. Terima kasih!")
            break
        else:
            print("Terima kasih!")
            break

    elif uang >= 14.000 and uang < 20.000:
        pesanan = input("""Anda dapat memesan 
    nasi goreng  
    pisang keju 
    Kue Bakar dan 
    Ayam goreng. 
    Apa yang ingin Anda pesan? 
    (nasi goreng/pisang keju/Kue Bakar/Ayam Goreng): """)
        
        if pesanan == ("nasi goreng") :
            print("Pesanan Anda: Nasi Goreng. Terima kasih!")
            break
        elif pesanan == ("pisang keju") :
            print("Pesanan Anda: Pisang Keju. Terima kasih!")
            break
        elif pesanan == ("Kue Bakar") :
            print("Pesanan Anda: Kue Bakar. Terima kasih!")
            break
        elif pesanan == ("Ayam Goreng") :
            print("Pesanan Anda: Ayam Goreng. Terima kasih!")
            break
        else:
            print("Maaf, pilihan tidak valid. Terima kasih!")
            break

    else:
        pesanan_nasi_goreng = input("Anda dapat memesan nasi goreng. Apakah Anda ingin memesannya? (ya/tidak): ")
        pesanan_pisang_keju = input("Anda juga dapat memesan pisang keju. Apakah Anda ingin memesannya? (ya/tidak): ")
        
        if pesanan_nasi_goreng == ("ya") and pesanan_pisang_keju == ("ya"):
            print("Pesanan Anda: Nasi Goreng dan Pisang Keju. Terima kasih!")
            break
        elif pesanan_nasi_goreng == ("ya"):
            print("Pesanan Anda: Nasi Goreng. Terima kasih!")
            break
        elif pesanan_pisang_keju == ("ya"):
            print("Pesanan Anda: Pisang Keju. Terima kasih!")
            break
        else:
            print("Terima kasih!")
            break