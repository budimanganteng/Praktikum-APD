celsius = float(input("Masukkan suhu dalam Celsius: "))

# Konversi suhu ke Fahrenheit, Reaumur, dan Kelvin
fahrenheit = (celsius * 9/5) + 32
reaumur = celsius * 4/5
kelvin = celsius + 273.15

Modulus_7= int(celsius)%7

kalimat = (
    f"{celsius:.2f} derajat Celsius setara dengan {fahrenheit:.2f} derajat Fahrenheit,"
    f"{reaumur:.2f} derajat Reaumur, dan {kelvin:.2f} Kelvin."
    f"{int(celsius)} modulus 7 sama dengan {Modulus_7}."
)
print (kalimat)