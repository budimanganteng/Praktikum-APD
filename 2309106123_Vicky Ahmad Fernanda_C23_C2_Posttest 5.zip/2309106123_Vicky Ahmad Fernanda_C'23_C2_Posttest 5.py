print("Selamat Datang Di gudang part Komputer")
print("Silahkan Registrasi terlebih dahulu")
data_akun = []
data_password = []
tanya = "iya"
while tanya == "iya" :
    a = input("Daftarkan Username anda : ")
    b = input("Daftarkan Password Anda : ")
    data_akun.append(a)
    data_password.append(b)
    print(data_akun,data_password)
    print('')
    c = False
    while c == False :
        tanya =  input("Daftarkan akun lagi (iya/tidak)? ")
        c = tanya == "iya" or tanya == "tidak"
        break
#Login
d = False
while d == False :
    s = input("Masukkan Username anda : ")
    d = s in data_akun
    if d == True:
        j = data_akun.index(s)
        r = False
        while r == False:
            p = input ("Masukkan Password anda : ")
            r = p == data_password[j]
            if r == True:
                break
            else:print("Password anda salah ")
    else:print("Mohon Maaf Username tidak terdaftar")
print("Login Berhasil")
print()

#Masuk Program
print("Barang di Gudang")
part_komputer = ["cashing","Power Supply", "Mouse", "Ram"]
print(part_komputer)

while True:
    try:
        print("1. Tampilkan data Part Komputer")
        print("2. Tambahkan data Part Komputer")
        print("3. Ubah data Part Komputer     ")
        print("4. Hapus data Part Komputer    ")
        print("==================")
        pilih_menu = input("Masukkan pilihan Anda: ")

        # Tampilkan data
        if pilih_menu == "1":
            for i in part_komputer:
                print("barang : ", i)

        # Tambahkan data
        elif pilih_menu == "2":
            m = input("Masukkan part komputer yang mau di Tambah : ")
            part_komputer.append(m)

        # Ubah data
        elif pilih_menu == "3":
            indeks = int(input("indeks berapa yang ingin diubah: "))
            m =  input("Masukkan part komputer yang mau di ubah: ")
            part_komputer[indeks]= m

        # Hapus data
        elif pilih_menu == "4":
                indeks = int(input("masukan indeks apa yang ingin di hapus: "))
                del part_komputer[indeks]

        else:print("Pilihan Anda Tidak Valid")
        
    except ValueError :
        print("tidak valid")

